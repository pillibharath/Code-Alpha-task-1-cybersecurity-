import React, { useState, useEffect } from 'react';
import { Shield, ChevronRight, ChevronLeft, CheckCircle, XCircle, Mail, AlertTriangle, Users, Lock, Trophy, Home } from 'lucide-react';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

interface Section {
  id: string;
  title: string;
  icon: React.ReactNode;
  content: React.ReactNode;
}

function App() {
  const [currentSection, setCurrentSection] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<{[key: number]: number}>({});
  const [showResults, setShowResults] = useState(false);
  const [completedSections, setCompletedSections] = useState<Set<number>>(new Set());

  const quizQuestions: QuizQuestion[] = [
    {
      id: 1,
      question: "Which of these email characteristics is the STRONGEST indicator of phishing?",
      options: [
        "The email has spelling mistakes",
        "The sender's email domain doesn't match the company",
        "The email asks for personal information",
        "The email has urgent language"
      ],
      correct: 1,
      explanation: "Domain spoofing is one of the most reliable indicators. Legitimate companies use their official domains."
    },
    {
      id: 2,
      question: "What should you do if you receive a suspicious email asking you to verify your account?",
      options: [
        "Click the link and enter your information if the website looks legitimate",
        "Forward the email to colleagues to get their opinion",
        "Go directly to the official website through a bookmark or search",
        "Reply to the email asking if it's legitimate"
      ],
      correct: 2,
      explanation: "Always navigate to official websites independently. Never use links from suspicious emails."
    },
    {
      id: 3,
      question: "Which social engineering tactic creates artificial time pressure?",
      options: [
        "Authority",
        "Scarcity",
        "Social proof",
        "Reciprocity"
      ],
      correct: 1,
      explanation: "Scarcity tactics use urgency and limited time offers to pressure victims into making quick decisions."
    },
    {
      id: 4,
      question: "What is 'spear phishing'?",
      options: [
        "Phishing emails sent to everyone in a company",
        "Targeted phishing attacks on specific individuals",
        "Phishing through text messages",
        "Phishing using fake phone calls"
      ],
      correct: 1,
      explanation: "Spear phishing is highly targeted, using personal information to make attacks more convincing."
    }
  ];

  const sections: Section[] = [
    {
      id: 'intro',
      title: 'Introduction to Phishing',
      icon: <Home className="w-6 h-6" />,
      content: (
        <div className="space-y-6">
          <div className="text-center">
            <Shield className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Welcome to Phishing Awareness Training</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Learn to protect yourself and your organization from one of the most common cyber threats today.
            </p>
          </div>
          
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-red-800">Did You Know?</h3>
                <p className="text-red-700 mt-1">
                  95% of successful cyber attacks start with a phishing email. Every 30 seconds, 
                  a new phishing site is created to steal personal information.
                </p>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
              <Mail className="w-8 h-8 text-blue-600 mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Email Phishing</h3>
              <p className="text-gray-600 text-sm">
                Fraudulent emails designed to steal credentials and personal information.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
              <Users className="w-8 h-8 text-blue-600 mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Social Engineering</h3>
              <p className="text-gray-600 text-sm">
                Psychological manipulation tactics used to trick victims into revealing information.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
              <Lock className="w-8 h-8 text-blue-600 mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Protection</h3>
              <p className="text-gray-600 text-sm">
                Learn practical strategies to identify and avoid phishing attempts.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'types',
      title: 'Types of Phishing Attacks',
      icon: <AlertTriangle className="w-6 h-6" />,
      content: (
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-gray-800 text-center">Types of Phishing Attacks</h2>
          
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3 flex items-center">
                <Mail className="w-5 h-5 text-red-500 mr-2" />
                Email Phishing
              </h3>
              <p className="text-gray-600 mb-4">
                The most common type where attackers send fraudulent emails impersonating trusted entities.
              </p>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm font-medium text-gray-700 mb-2">Common characteristics:</p>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Generic greetings ("Dear Customer")</li>
                  <li>• Urgent language and threats</li>
                  <li>• Suspicious links and attachments</li>
                  <li>• Poor grammar and spelling</li>
                </ul>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Spear Phishing
              </h3>
              <p className="text-gray-600 mb-4">
                Targeted attacks using personal information to appear more legitimate and trustworthy.
              </p>
              <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
                <p className="text-sm text-yellow-800">
                  <strong>Example:</strong> An email appearing to be from your CEO asking you to urgently 
                  transfer funds, using your name and company details.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Whaling
              </h3>
              <p className="text-gray-600 mb-4">
                High-value targets like executives and decision-makers are specifically targeted.
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Smishing & Vishing
              </h3>
              <p className="text-gray-600 mb-4">
                Phishing through SMS messages (smishing) and voice calls (vishing).
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'recognition',
      title: 'Recognizing Phishing Emails',
      icon: <Mail className="w-6 h-6" />,
      content: (
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-gray-800 text-center">How to Recognize Phishing Emails</h2>
          
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-red-800 mb-4">⚠️ Example: Phishing Email</h3>
            <div className="bg-white rounded-md p-4 border border-gray-300">
              <div className="text-sm space-y-2">
                <p><strong>From:</strong> security-team@amaz0n-security.com</p>
                <p><strong>Subject:</strong> URGENT: Your account will be suspended in 24 hours</p>
                <div className="border-t pt-2 mt-2">
                  <p className="text-gray-800">Dear Valued Customer,</p>
                  <p className="mt-2">We have detected suspicious activity on your account. Your account will be permanently suspended within 24 hours unless you verify your information immediately.</p>
                  <p className="mt-2">Click here to verify: <span className="text-blue-600 underline">http://amaz0n-verify.suspiciousdomain.com</span></p>
                  <p className="mt-2">Amazon Security Team</p>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <h4 className="font-semibold text-red-800 mb-2">🚩 Red Flags Identified:</h4>
              <ul className="text-red-700 space-y-1 text-sm">
                <li>• Suspicious sender domain (amaz0n instead of amazon)</li>
                <li>• Generic greeting ("Dear Valued Customer")</li>
                <li>• Creates urgency ("24 hours", "immediately")</li>
                <li>• Suspicious link domain</li>
                <li>• Threatens account suspension</li>
              </ul>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-green-700">✅ Legitimate Email Signs</h3>
              <div className="space-y-3">
                <div className="bg-green-50 p-3 rounded-md border border-green-200">
                  <p className="font-medium text-green-800">Sender Domain</p>
                  <p className="text-green-700 text-sm">Matches official company domain exactly</p>
                </div>
                <div className="bg-green-50 p-3 rounded-md border border-green-200">
                  <p className="font-medium text-green-800">Personal Greeting</p>
                  <p className="text-green-700 text-sm">Uses your actual name, not generic terms</p>
                </div>
                <div className="bg-green-50 p-3 rounded-md border border-green-200">
                  <p className="font-medium text-green-800">Professional Language</p>
                  <p className="text-green-700 text-sm">Proper grammar, spelling, and formatting</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-red-700">❌ Phishing Warning Signs</h3>
              <div className="space-y-3">
                <div className="bg-red-50 p-3 rounded-md border border-red-200">
                  <p className="font-medium text-red-800">Urgent Threats</p>
                  <p className="text-red-700 text-sm">"Act now or lose your account!"</p>
                </div>
                <div className="bg-red-50 p-3 rounded-md border border-red-200">
                  <p className="font-medium text-red-800">Suspicious Links</p>
                  <p className="text-red-700 text-sm">URLs that don't match the claimed sender</p>
                </div>
                <div className="bg-red-50 p-3 rounded-md border border-red-200">
                  <p className="font-medium text-red-800">Information Requests</p>
                  <p className="text-red-700 text-sm">Asking for passwords or personal data</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'social-engineering',
      title: 'Social Engineering Tactics',
      icon: <Users className="w-6 h-6" />,
      content: (
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-gray-800 text-center">Social Engineering Tactics</h2>
          
          <p className="text-center text-lg text-gray-600 max-w-3xl mx-auto">
            Attackers use psychological manipulation to exploit human behavior. Understanding these tactics 
            helps you recognize and resist social engineering attempts.
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Authority
              </h3>
              <p className="text-gray-600 mb-4">
                Pretending to be someone in a position of power or authority.
              </p>
              <div className="bg-blue-50 p-3 rounded-md border border-blue-200">
                <p className="text-sm text-blue-800">
                  <strong>Example:</strong> "This is your IT manager. I need your password to fix your account immediately."
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Urgency/Scarcity
              </h3>
              <p className="text-gray-600 mb-4">
                Creating artificial time pressure to force quick decisions.
              </p>
              <div className="bg-orange-50 p-3 rounded-md border border-orange-200">
                <p className="text-sm text-orange-800">
                  <strong>Example:</strong> "Your account expires in 1 hour! Click now to avoid losing access!"
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Trust/Likability
              </h3>
              <p className="text-gray-600 mb-4">
                Building rapport and appearing friendly or helpful.
              </p>
              <div className="bg-green-50 p-3 rounded-md border border-green-200">
                <p className="text-sm text-green-800">
                  <strong>Example:</strong> "Hi! I'm new to the IT team and helping everyone update their passwords. What's yours?"
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">
                Fear
              </h3>
              <p className="text-gray-600 mb-4">
                Using threats and negative consequences to motivate action.
              </p>
              <div className="bg-red-50 p-3 rounded-md border border-red-200">
                <p className="text-sm text-red-800">
                  <strong>Example:</strong> "We've detected malware on your computer. Download this tool or risk losing all your data!"
                </p>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-yellow-800 mb-3">🧠 How to Resist Social Engineering</h3>
            <ul className="text-yellow-800 space-y-2">
              <li>• <strong>Take time to think:</strong> Don't make hasty decisions under pressure</li>
              <li>• <strong>Verify independently:</strong> Contact the person through official channels</li>
              <li>• <strong>Trust your instincts:</strong> If something feels wrong, it probably is</li>
              <li>• <strong>Follow policies:</strong> Legitimate requests follow established procedures</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 'best-practices',
      title: 'Best Practices',
      icon: <Lock className="w-6 h-6" />,
      content: (
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-gray-800 text-center">Best Practices for Protection</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Email Security</h3>
              <div className="space-y-4">
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Verify Sender Identity</h4>
                  <p className="text-gray-600 text-sm">
                    Always verify the sender through a separate communication channel before taking action.
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Check URLs Carefully</h4>
                  <p className="text-gray-600 text-sm">
                    Hover over links to preview the destination. Look for misspellings and suspicious domains.
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Don't Download Attachments</h4>
                  <p className="text-gray-600 text-sm">
                    Avoid opening unexpected attachments, especially from unknown senders.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Account Security</h3>
              <div className="space-y-4">
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Use Multi-Factor Authentication</h4>
                  <p className="text-gray-600 text-sm">
                    Enable MFA on all important accounts to add an extra layer of security.
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibent text-gray-800 mb-2">Keep Software Updated</h4>
                  <p className="text-gray-600 text-sm">
                    Regular updates patch security vulnerabilities that attackers might exploit.
                  </p>
                </div>
                <div className="bg-white rounded-lg shadow-md border border-gray-200 p-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Use Strong, Unique Passwords</h4>
                  <p className="text-gray-600 text-sm">
                    Each account should have a unique password managed by a password manager.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-blue-800 mb-3">🛡️ What to Do If You Suspect Phishing</h3>
            <ol className="text-blue-800 space-y-2 list-decimal list-inside">
              <li><strong>Don't panic:</strong> Take time to assess the situation calmly</li>
              <li><strong>Don't click anything:</strong> Avoid clicking links or downloading attachments</li>
              <li><strong>Report it:</strong> Forward suspicious emails to your IT security team</li>
              <li><strong>Verify independently:</strong> Contact the supposed sender through official channels</li>
              <li><strong>Change passwords:</strong> If you accidentally entered credentials, change them immediately</li>
            </ol>
          </div>
        </div>
      )
    },
    {
      id: 'quiz',
      title: 'Knowledge Quiz',
      icon: <Trophy className="w-6 h-6" />,
      content: (
        <div className="space-y-8">
          <h2 className="text-3xl font-bold text-gray-800 text-center">Test Your Knowledge</h2>
          
          {!showResults ? (
            <div className="space-y-6">
              {quizQuestions.map((q) => (
                <div key={q.id} className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Question {q.id}: {q.question}
                  </h3>
                  <div className="space-y-3">
                    {q.options.map((option, index) => (
                      <label 
                        key={index}
                        className="flex items-center space-x-3 p-3 rounded-md border border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors"
                      >
                        <input
                          type="radio"
                          name={`question-${q.id}`}
                          value={index}
                          checked={quizAnswers[q.id] === index}
                          onChange={() => setQuizAnswers({...quizAnswers, [q.id]: index})}
                          className="text-blue-600"
                        />
                        <span className="text-gray-700">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
              
              <div className="text-center">
                <button
                  onClick={() => setShowResults(true)}
                  disabled={Object.keys(quizAnswers).length !== quizQuestions.length}
                  className="px-8 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                >
                  Submit Quiz
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <Trophy className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">Quiz Complete!</h3>
                <p className="text-lg text-gray-600">
                  You scored {Object.keys(quizAnswers).filter(key => quizAnswers[parseInt(key)] === quizQuestions.find(q => q.id === parseInt(key))?.correct).length} out of {quizQuestions.length}
                </p>
              </div>

              {quizQuestions.map((q) => {
                const userAnswer = quizAnswers[q.id];
                const isCorrect = userAnswer === q.correct;
                return (
                  <div key={q.id} className="bg-white rounded-lg shadow-md border border-gray-200 p-6">
                    <div className="flex items-start space-x-3 mb-3">
                      {isCorrect ? (
                        <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                      )}
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-800 mb-2">Question {q.id}: {q.question}</h4>
                        <p className={`text-sm mb-2 ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                          Your answer: {q.options[userAnswer]}
                        </p>
                        {!isCorrect && (
                          <p className="text-sm text-green-700 mb-2">
                            Correct answer: {q.options[q.correct]}
                          </p>
                        )}
                        <p className="text-sm text-gray-600">{q.explanation}</p>
                      </div>
                    </div>
                  </div>
                );
              })}

              <div className="text-center">
                <button
                  onClick={() => {
                    setShowResults(false);
                    setQuizAnswers({});
                  }}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                >
                  Retake Quiz
                </button>
              </div>
            </div>
          )}
        </div>
      )
    }
  ];

  const handleNext = () => {
    if (currentSection < sections.length - 1) {
      setCompletedSections(prev => new Set([...prev, currentSection]));
      setCurrentSection(currentSection + 1);
    }
  };

  const handlePrevious = () => {
    if (currentSection > 0) {
      setCurrentSection(currentSection - 1);
    }
  };

  const progressPercentage = ((currentSection + 1) / sections.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-800">Phishing Awareness Training</h1>
            </div>
            <div className="text-sm text-gray-600">
              Section {currentSection + 1} of {sections.length}
            </div>
          </div>
          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sidebar */}
      <div className="flex">
        <div className="w-80 bg-white shadow-lg min-h-screen">
          <div className="p-6">
            <h2 className="font-semibold text-gray-800 mb-4">Training Modules</h2>
            <nav className="space-y-2">
              {sections.map((section, index) => (
                <button
                  key={section.id}
                  onClick={() => setCurrentSection(index)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                    currentSection === index
                      ? 'bg-blue-100 text-blue-700 border border-blue-200'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <div className={`flex items-center justify-center w-6 h-6 ${
                    completedSections.has(index) ? 'text-green-600' : ''
                  }`}>
                    {completedSections.has(index) ? <CheckCircle className="w-5 h-5" /> : section.icon}
                  </div>
                  <span className="font-medium">{section.title}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-8 mb-8">
              {sections[currentSection].content}
            </div>

            {/* Navigation Buttons */}
            <div className="flex justify-between items-center">
              <button
                onClick={handlePrevious}
                disabled={currentSection === 0}
                className="flex items-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
                <span>Previous</span>
              </button>

              <button
                onClick={handleNext}
                disabled={currentSection === sections.length - 1}
                className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <span>Next</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;